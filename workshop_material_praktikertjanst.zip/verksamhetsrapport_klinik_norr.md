# Månadsrapport – Klinik Norr (Tandvård)
**Period:** Februari 2025
**Klinikchef:** Anna Lindström

## Sammanfattning
Februari har varit en utmanande månad med hög sjukfrånvaro bland tandhygienisterna vilket påverkat både beläggning och intäkter. Vi har dock sett en positiv trend i antal nya patienter tack vare marknadsföringskampanjen på sociala medier.

## Ekonomi
- **Omsättning:** 1 420 000 kr (budget: 1 550 000 kr, -8,4%)
- **Beläggningsgrad:** 72% (mål: 85%)
- **Materialkostnad:** 185 000 kr (13% av omsättning, mål <12%)
- **Personalkostnad:** 890 000 kr (63% av omsättning)
- **Resultat före overhead:** 145 000 kr (budget: 280 000 kr)

## Personal
- **Antal anställda:** 12 (8 tandläkare, 3 tandhygienister, 1 receptionist)
- **Sjukfrånvaro:** 9,2% (två tandhygienister sjukskrivna sedan v.5)
- **Övertid:** 42 timmar totalt, främst bland tandläkarna som kompenserat för hygienistbristen
- **Kompetensutveckling:** Tandläkare Erik Johansson genomförde kurs i digital avtryckstagning (2 dagar)

## Patienter
- **Antal unika patienter:** 485 (förra månaden: 520)
- **Nya patienter:** 38 (förra månaden: 22) – positivt!
- **Avbokningar/no-shows:** 12% (mål <8%)
- **Patientnöjdhet (NPS):** 62 (förra månaden: 68)

## Utmaningar
1. Sjukfrånvaron bland hygienisterna skapar flaskhalsar – vi har tvingats boka om ca 60 patienter
2. Materialkostnaderna har ökat p.g.a. prisökning på tandtekniska arbeten (+15% från leverantören)
3. En tandläkare (Maria Svensson) har flaggat att hon överväger att gå ner i tid p.g.a. arbetsbelastning

## Möjligheter
- Den digitala marknadsföringen ger tydlig effekt – 38 nya patienter är vår bästa siffra på 6 månader
- Erik Johanssons nya kompetens i digital avtryckstagning kan minska tandteknikerkostnader med ca 20%
- En erfaren tandhygienist (Lena Karlsson) har visat intresse för vikariat via bemanningsföretag

## Behov av stöd
- Beslut kring vikarielösning för hygienisterna – jag vill anlita Lena Karlsson men behöver budget
- Diskussion om Maria Svenssons situation – behöver stöd i det samtalet
- Översyn av tandteknikeravtalet – nuvarande priser är inte hållbara

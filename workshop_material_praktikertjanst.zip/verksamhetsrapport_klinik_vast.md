# Månadsrapport – Klinik Väst (Tandvård)
**Period:** Februari 2025
**Klinikchef:** Karin Björk

## Sammanfattning
Vi kämpar. Personalbristen som pågått sedan november börjar synas tydligt i siffrorna. Stämningen på kliniken är pressad och jag är orolig för fler uppsägningar om vi inte agerar snabbt. Jag behöver verkligen stöd från centralt håll.

## Ekonomi
- **Omsättning:** 980 000 kr (budget: 1 300 000 kr, -24,6%)
- **Beläggningsgrad:** 61% (mål: 85%)
- **Materialkostnad:** 108 000 kr (11% av omsättning)
- **Personalkostnad:** 720 000 kr (73% av omsättning – för högt!)
- **Resultat före overhead:** -48 000 kr (budget: 180 000 kr) – NEGATIVT RESULTAT

## Personal
- **Antal anställda:** 8 (5 tandläkare, 2 tandhygienister, 1 receptionist)
- **Vakanser:** 2 tandläkare (en sade upp sig i nov, en gick i pension i jan)
- **Sjukfrånvaro:** 14,2% (receptionisten långtidssjukskriven sedan v.3, en tandhygienist intermittent sjuk)
- **Övertid:** 68 timmar – ohållbar nivå, särskilt för de tre kvarvarande tandläkarna
- **Personalomsättning senaste 12 mån:** 3 av 10 (30%) – alarmerande

## Patienter
- **Antal unika patienter:** 290 (förra månaden: 340)
- **Nya patienter:** 12 (vi har stängt nypatientintag tillfälligt)
- **Avbokningar/no-shows:** 9%
- **Patientnöjdhet (NPS):** 48 (förra månaden: 52, trend: nedåt)
- **Väntelista:** 85 patienter väntar på tid

## Utmaningar
1. AKUT: Vi förlorar pengar. -48 000 kr denna månad och trenden är nedåt
2. AKUT: Personalen är utarbetad. 68 timmars övertid på 5 tandläkare är inte hållbart
3. Receptionistens sjukskrivning innebär att tandläkarna hanterar telefoner och bokning själva
4. Patientnöjdheten sjunker – vi ger inte den kvalitet vi vill
5. Väntelistan på 85 patienter skapar frustration och vi riskerar att tappa dem

## Möjligheter
- Vi har ett bra rykte i området – om vi bemannar upp kommer patienterna tillbaka
- Lokalmässigt finns kapacitet för ytterligare 2 behandlingsrum
- Tandläkare Lisa Nordin (senior) har erbjudit sig att handleda eventuella nyanställda

## Behov av stöd (BRÅDSKANDE)
- Rekryteringsstöd: Behöver minst 2 tandläkare ASAP – kan centralt hjälpa med annonsering och headhunting?
- Vikarielösning för receptionist – administrationen kollapsar
- Ekonomisk plan: Hur länge accepteras negativt resultat? Behöver veta planen
- Personalstöd: Kan HR erbjuda samtalsstöd/företagshälsa till teamet? De mår inte bra

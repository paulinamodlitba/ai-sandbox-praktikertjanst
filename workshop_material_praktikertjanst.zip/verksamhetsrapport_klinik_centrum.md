# Månadsrapport – Klinik Centrum (Tandvård)
**Period:** Februari 2025
**Klinikchef:** Johan Petersson

## Sammanfattning
Stabil månad med goda resultat. Vi har hittat en bra rytm efter omorganisationen i höstas och teamet fungerar väl. Fokus har legat på att öka andelen protetikbehandlingar som har högre marginal, och det börjar ge resultat.

## Ekonomi
- **Omsättning:** 1 890 000 kr (budget: 1 800 000 kr, +5,0%)
- **Beläggningsgrad:** 88% (mål: 85%)
- **Materialkostnad:** 245 000 kr (13% av omsättning – protetik driver upp materialkostnaden)
- **Personalkostnad:** 1 100 000 kr (58% av omsättning – effektivt)
- **Resultat före overhead:** 345 000 kr (budget: 290 000 kr)

## Personal
- **Antal anställda:** 14 (9 tandläkare, 3 tandhygienister, 2 receptionister)
- **Sjukfrånvaro:** 2,8% (lågt, en korttidsfrånvaro)
- **Övertid:** 12 timmar (marginellt)
- **Kompetensutveckling:** Tre tandläkare genomgår protetikutbildning (pågående, avslutas april)
- **Medarbetarsamtal:** Alla genomförda under februari, inga orosmoln

## Patienter
- **Antal unika patienter:** 580
- **Nya patienter:** 42
- **Avbokningar/no-shows:** 5% (under mål – bra!)
- **Patientnöjdhet (NPS):** 78 (bästa siffran i regionen)
- **Andel protetik av total behandling:** 28% (förra månaden: 22%)

## Utmaningar
1. Materialkostnaden ökar med protetikstrategin – vi behöver bättre avtal med tandtekniker
2. En av receptionisterna (Elin) har flaggat att hon vill utvecklas – risk att vi tappar henne om vi inte kan erbjuda karriärväg
3. Lokalerna börjar bli trånga vid lunchtid – schemasystemet behöver optimeras

## Möjligheter
- Protetikstrategin fungerar: +6 procentenheter på en månad, med potential att nå 35% i Q2
- Teamets stabilitet ger oss utrymme att ta emot eventuella patienter från Klinik Väst (väntelista)
- Elin på receptionen har sjuksköterskebakgrund – kan hon utbildas till behandlingskoordinator?

## Behov av stöd
- Förhandlingsstöd för tandteknikeravtalet – de har höjt priserna 2 gånger på 6 månader
- Diskussion om Elins karriärutveckling – finns det en roll som behandlingskoordinator centralt?
- Eventuell kapacitetsöverföring: Kan vi ta emot Klinik Västs patienter tillfälligt?

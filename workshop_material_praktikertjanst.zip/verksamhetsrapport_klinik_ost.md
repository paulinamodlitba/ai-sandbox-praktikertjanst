# Månadsrapport – Klinik Öst (Tandvård & Ortodonti)
**Period:** Februari 2025
**Klinikchef:** Sara Nilsson

## Sammanfattning
Februari var en blandad månad. Ortodontiavdelningen går fantastiskt bra med väntelista, medan den allmänna tandvården tappar patienter till en nyöppnad konkurrerande klinik i området. Vi behöver agera snabbt på konkurrenssituationen.

## Ekonomi
- **Omsättning totalt:** 1 750 000 kr (budget: 1 700 000 kr, +2,9%)
  - Allmän tandvård: 1 050 000 kr (-7% mot budget)
  - Ortodonti: 700 000 kr (+22% mot budget)
- **Beläggningsgrad:** Allmän tandvård 74%, Ortodonti 96%
- **Materialkostnad:** 230 000 kr (13,1% av omsättning)
- **Personalkostnad:** 1 080 000 kr (61,7% av omsättning)
- **Resultat före overhead:** 240 000 kr (budget: 220 000 kr)

## Personal
- **Antal anställda:** 15 (7 tandläkare, 2 ortodontister, 3 tandhygienister, 2 tandsköterskor, 1 receptionist)
- **Sjukfrånvaro:** 5,4% (en tandsköterska korttidssjuk, en tandläkare VAB)
- **Övertid:** 28 timmar (ortodontisterna arbetar extra för att beta av väntelistan)
- **Nyanställning pågår:** Vi söker ytterligare en ortodontist – 4 sökande hittills

## Patienter
- **Antal unika patienter:** Allmän tandvård 420, Ortodonti 180
- **Nya patienter:** Allmän tandvård 18 (förra månaden: 32 – kraftig minskning!), Ortodonti 24
- **Avbokningar/no-shows:** 7% allmän, 3% ortodonti
- **Patientnöjdhet (NPS):** Allmän tandvård 61, Ortodonti 82
- **Ortodonti väntelista:** 45 patienter (beräknad väntetid: 3 månader)

## Utmaningar
1. PRIORITERAT: Ny konkurrerande klinik "Tandklinik24" öppnade i januari med aggressiv prissättning. Vi tappar nya patienter inom allmän tandvård
2. Ortodontins framgång skapar kapacitetsbrist – 45 patienter väntar och vi riskerar att de söker sig till andra
3. Löneläget: Två tandläkare har nämnt att de fått erbjudanden från Tandklinik24 med 15% högre lön

## Möjligheter
- Ortodontin är en guldgruva – om vi kan rekrytera en till ortodontist kan vi öka intäkterna med ca 400 000 kr/månad
- Digital marknadsföring riktad mot ortodonti kan kapitalisera på vår starka NPS (82)
- Samarbete med barnmorskemottagningen i området för tidig ortodontisk screening

## Behov av stöd
- BRÅDSKANDE: Löneöversyn för de två tandläkarna som fått konkurrerande erbjudanden – vi har inte råd att tappa dem
- Marknadsföringsstöd: Budget för riktad kampanj mot den nya konkurrenten – kan centralt hjälpa?
- Rekrytering ortodontist: Accelerera processen, kan vi erbjuda signeringsbonus?
- Strategisk fråga: Bör vi sänka priser för att matcha Tandklinik24, eller differentiera oss på kvalitet?
